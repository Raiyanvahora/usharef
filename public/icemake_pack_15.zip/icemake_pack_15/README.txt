Icemake Pack (15 Products)
==========================

What’s inside
-------------
- products_for_site.csv — matches your site schema from the sample
- /product_copy/*.md — ready-to-paste product copy per model
- expected_image_names.txt — list of filenames to use
- /assets/icemake/ — destination folder for images (empty, you’ll add files)
- /scripts/move_images.sh and move_images.ps1 — rename/move templates

How to use
----------
1) Put your downloaded images into **raw/** (create it next to /scripts).
2) Edit the script (bash or PowerShell) to map your raw filenames to the expected ones.
3) Run the script to copy into **assets/icemake/**.
4) Import **products_for_site.csv** into your site / CMS.
5) In your frontend, ensure product image tags use `object-fit: contain;` to prevent cropping.

Notes
-----
- Dimensions and temperature ranges are typical values for these model classes.
- Warranty lines are generic; replace with your vendor’s exact terms if needed.
- Slugs and meta descriptions are provided inside each Markdown for SEO.

Expected filenames
------------------
IFC425.jpg, IFC525.jpg, IGT350.jpg, IGT450.jpg, IGT550.jpg, IHT175SD.jpg, IHT250.jpg, IHT350.jpg, IHT450.jpg, IHT550.jpg, IHT650.jpg, IMVC300.jpg, IMVC450.jpg, IMVC550.jpg, IMVC900.jpg
