# Icemake IMVC900 – 1009 L Visi Cooler

    **Category:** Visi Cooler  
    **Capacity:** 1009 L  
    **Configuration:** Double door  
    **Temperature Range:** +2° to +8°C  
    **Dimensions:** ≈1180×722×1900 mm  
    **Warranty:** Product 1 year (typ.)

    ## Highlights
    - Double‑door high‑volume display
- Eight shelves configuration
- LED‑lit merchandising
- Lockable doors, castors

    ## Overview
    The IMVC900 offers dependable cooling performance with efficient insulation and a durable build. It’s designed for daily retail use, with easy‑clean interiors, lockable access, and smooth mobility. 

    ## What to know
    - Estimated dimensions & ranges are typical for this model class. Please verify with your distributor if you need exact specs for tenders.
    - Use **object-fit: contain** on product cards to prevent image cropping on mobile.

    ## SEO
    - **Slug:** `icemake-imvc900`
    - **Meta description:** Icemake IMVC900 – 1009 L Visi Cooler. Visi Cooler. Temperature: +2° to +8°C. Dimensions: ≈1180×722×1900 mm. Built for Indian retail conditions.
