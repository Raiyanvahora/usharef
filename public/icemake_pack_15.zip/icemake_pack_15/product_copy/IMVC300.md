# Icemake IMVC300 – 333 L Visi Cooler

    **Category:** Visi Cooler  
    **Capacity:** 333 L  
    **Configuration:** Single door  
    **Temperature Range:** +2° to +8°C  
    **Dimensions:** ≈520×722×1673 mm  
    **Warranty:** Product 1 year (typ.)

    ## Highlights
    - Fog‑free toughened glass
- Adjustable shelves
- Vertical LED lighting
- Lockable, castor wheels

    ## Overview
    The IMVC300 offers dependable cooling performance with efficient insulation and a durable build. It’s designed for daily retail use, with easy‑clean interiors, lockable access, and smooth mobility. 

    ## What to know
    - Estimated dimensions & ranges are typical for this model class. Please verify with your distributor if you need exact specs for tenders.
    - Use **object-fit: contain** on product cards to prevent image cropping on mobile.

    ## SEO
    - **Slug:** `icemake-imvc300`
    - **Meta description:** Icemake IMVC300 – 333 L Visi Cooler. Visi Cooler. Temperature: +2° to +8°C. Dimensions: ≈520×722×1673 mm. Built for Indian retail conditions.
