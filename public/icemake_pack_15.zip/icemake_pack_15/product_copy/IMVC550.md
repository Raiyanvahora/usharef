# Icemake IMVC550 – 569 L Visi Cooler

    **Category:** Visi Cooler  
    **Capacity:** 569 L  
    **Configuration:** Single door  
    **Temperature Range:** +2° to +8°C  
    **Dimensions:** ≈580×775×2200 mm  
    **Warranty:** Product 1 year (typ.)

    ## Highlights
    - Higher capacity visi cooler
- Fog‑free display
- Adjustable shelves & LED
- Retail‑grade reliability

    ## Overview
    The IMVC550 offers dependable cooling performance with efficient insulation and a durable build. It’s designed for daily retail use, with easy‑clean interiors, lockable access, and smooth mobility. 

    ## What to know
    - Estimated dimensions & ranges are typical for this model class. Please verify with your distributor if you need exact specs for tenders.
    - Use **object-fit: contain** on product cards to prevent image cropping on mobile.

    ## SEO
    - **Slug:** `icemake-imvc550`
    - **Meta description:** Icemake IMVC550 – 569 L Visi Cooler. Visi Cooler. Temperature: +2° to +8°C. Dimensions: ≈580×775×2200 mm. Built for Indian retail conditions.
