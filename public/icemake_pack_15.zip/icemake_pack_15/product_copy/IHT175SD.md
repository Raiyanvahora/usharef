# Icemake IHT175 SD – 100 L Hard Top Deep Freezer

    **Category:** Hard Top Deep Freezer  
    **Capacity:** 100 L  
    **Configuration:** Single lid  
    **Temperature Range:** +3° to −25°C (convertible)  
    **Dimensions:** ≈640×640×885 mm  
    **Warranty:** Product 1 year; Compressor 3 years

    ## Highlights
    - Compact footprint for tight spaces
- Convertible cooler/freezer range
- Lock & key, anti‑bacterial gasket
- Easy mobility on castors

    ## Overview
    The IHT175 SD offers dependable cooling performance with efficient insulation and a durable build. It’s designed for daily retail use, with easy‑clean interiors, lockable access, and smooth mobility. 

    ## What to know
    - Estimated dimensions & ranges are typical for this model class. Please verify with your distributor if you need exact specs for tenders.
    - Use **object-fit: contain** on product cards to prevent image cropping on mobile.

    ## SEO
    - **Slug:** `icemake-iht175-sd`
    - **Meta description:** Icemake IHT175 SD – 100 L Hard Top Deep Freezer. Hard Top Deep Freezer. Temperature: +3° to −25°C (convertible). Dimensions: ≈640×640×885 mm. Built for Indian retail conditions.
