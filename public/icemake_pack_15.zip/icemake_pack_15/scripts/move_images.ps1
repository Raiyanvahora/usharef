# PowerShell: Move/rename images into .\assets\icemake\
# Usage: place raw images in .\raw and run: powershell -ExecutionPolicy Bypass -File scripts\move_images.ps1
$Raw = Join-Path $PSScriptRoot "..\raw"
$Dest = Join-Path $PSScriptRoot "..\assets\icemake"
New-Item -ItemType Directory -Path $Dest -Force | Out-Null

# EDIT the right-hand side filenames if your raw names differ.
# Copy-Item (Join-Path $Raw "YOUR_FILE.jpg") (Join-Path $Dest "TARGET_FILE.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IFC425.jpg") (Join-Path $Dest "IFC425.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IFC525.jpg") (Join-Path $Dest "IFC525.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IGT350.jpg") (Join-Path $Dest "IGT350.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IGT450.jpg") (Join-Path $Dest "IGT450.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IGT550.jpg") (Join-Path $Dest "IGT550.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IHT175SD.jpg") (Join-Path $Dest "IHT175SD.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IHT250.jpg") (Join-Path $Dest "IHT250.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IHT350.jpg") (Join-Path $Dest "IHT350.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IHT450.jpg") (Join-Path $Dest "IHT450.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IHT550.jpg") (Join-Path $Dest "IHT550.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IHT650.jpg") (Join-Path $Dest "IHT650.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IMVC300.jpg") (Join-Path $Dest "IMVC300.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IMVC450.jpg") (Join-Path $Dest "IMVC450.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IMVC550.jpg") (Join-Path $Dest "IMVC550.jpg")
# Copy-Item (Join-Path $Raw "YOUR_IMVC900.jpg") (Join-Path $Dest "IMVC900.jpg")
