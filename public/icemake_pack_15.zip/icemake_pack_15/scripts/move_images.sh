#!/usr/bin/env bash
# Move/rename your raw images into assets/icemake with the expected names.
# Usage: put your downloaded images inside ./raw/ and run: bash scripts/move_images.sh
set -euo pipefail
mkdir -p "$(dirname "$0")/../assets/icemake"
RAW_DIR="$(dirname "$0")/../raw"
DEST_DIR="$(dirname "$0")/../assets/icemake"
cd "$RAW_DIR"

# EDIT the right-hand side filenames if your raw names differ.
# left = your raw file; right = target name
# cp "YOUR_IFC425.jpg" "../assets/icemake/IFC425.jpg"
# cp "YOUR_IFC525.jpg" "../assets/icemake/IFC525.jpg"
# cp "YOUR_IGT350.jpg" "../assets/icemake/IGT350.jpg"
# cp "YOUR_IGT450.jpg" "../assets/icemake/IGT450.jpg"
# cp "YOUR_IGT550.jpg" "../assets/icemake/IGT550.jpg"
# cp "YOUR_IHT175SD.jpg" "../assets/icemake/IHT175SD.jpg"
# cp "YOUR_IHT250.jpg" "../assets/icemake/IHT250.jpg"
# cp "YOUR_IHT350.jpg" "../assets/icemake/IHT350.jpg"
# cp "YOUR_IHT450.jpg" "../assets/icemake/IHT450.jpg"
# cp "YOUR_IHT550.jpg" "../assets/icemake/IHT550.jpg"
# cp "YOUR_IHT650.jpg" "../assets/icemake/IHT650.jpg"
# cp "YOUR_IMVC300.jpg" "../assets/icemake/IMVC300.jpg"
# cp "YOUR_IMVC450.jpg" "../assets/icemake/IMVC450.jpg"
# cp "YOUR_IMVC550.jpg" "../assets/icemake/IMVC550.jpg"
# cp "YOUR_IMVC900.jpg" "../assets/icemake/IMVC900.jpg"
